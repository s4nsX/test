# igfirst

Tutorial :

Git clone https://github.com/zippien/igfirst.git

cd igfirst

npm install -g npm

node go.js

Done.

Put username and password for login

Then input your target with "," . for ex: 9gag,instagram,etc

after your have done with your target, put delay 200 and 100, but i recomend about 350 and 150
Done,, have fun with your first comment bot on instagram
